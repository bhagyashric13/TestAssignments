<?php


//This file contains the commonly used variables 

$parent_tab_info_array=array(1=>'My Home Page',2=>'Marketing',3=>'Sales',4=>'Support',5=>'Analytics',6=>'Inventory',7=>'Tools',8=>'Settings');


$parent_child_tab_rel_array=array(1=>array(3,9,28,),2=>array(26,6,4,28,7,9,8,),3=>array(7,6,4,2,20,22,23,19,8,9,),4=>array(13,15,6,4,8,28,9,35,35,43,43,44,44,45,45,),5=>array(25,1,),6=>array(14,18,19,21,22,20,23,36,36,38,38,),7=>array(24,27,8,31,31,34,34,40,40,42,42,46,46,47,47,50,50,),8=>array(49,49,),);



?>