<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
$languageStrings = array(
	'SINGLE_Calendar'              => 'Pour faire'                      , 
	'LBL_ADD_TASK'                 => 'Add Pour faire'                    , 
	'LBL_ADD_EVENT'                => 'Ajouter activité'           , 
	'LBL_RECORDS_LIST'             => 'Liste'                       , 
	'LBL_EVENTS'                   => 'Evènements'                 , 
	'LBL_TODOS'                    => 'Tâches'                     , 
	'LBL_CALENDAR_SETTINGS'        => 'Calendar Settings'           , // TODO: Review
	'LBL_CALENDAR_SHARING'         => 'Calendar Sharing'            , // TODO: Review
	'LBL_DEFAULT_EVENT_DURATION'   => 'Default Event Duration'      , // TODO: Review
	'LBL_CALL'                     => 'Call'                        , // TODO: Review
	'LBL_OTHER_EVENTS'             => 'Other Events'                , // TODO: Review
	'LBL_MINUTES'                  => 'Minutes'                     , // TODO: Review
	'LBL_SELECT_USERS'             => 'Select Users'                , // TODO: Review
	'LBL_EVENT_OR_TASK'            => 'Evénement / Pour faire'                ,
	'LBL_TASK_INFORMATION'         => 'Pour faire Information'                 , 
    'LBL_EVENT_INFORMATION'        => 'Détails de lévénement'   ,
	'Subject'                      => 'Sujet'                       , 
	'Start Date & Time'            => 'Date & heure de début'      , 
	'Activity Type'                => 'Type'                        , 
	'Send Notification'            => 'Envoyer notification'        , 
	'Location'                     => 'Localisation'                , 
	'End Date & Time'              => 'Date et heure de fin'        , 
	'LBL_ACTIVITY_TYPES'           => 'Activity Types'              , 
	'LBL_CONTACTS_SUPPORT_END_DATE' => 'Fin de support'              , 
	'LBL_CONTACTS_BIRTH_DAY'       => 'Date of Birth'               , 
	'LBL_ADDED_CALENDARS'          => 'Added Calendars'             , // TODO: Review
	'Call'                         => 'Appels'                      , 
	'Meeting'                      => 'Rendez-vous'                 , 
	'Task'                         => 'Pour faire'                        , // TODO: Review
	'Planned'                      => 'Prévu'                   , 
        'Held'                         => 'Tenue',
        'Not Held'                     => 'Pas tenue',
	'Completed'                    => 'Terminé'                    , 
	'Pending Input'                => 'En attente'                  , 
	'Not Started'                  => 'Non commencé'               , 
	'Deferred'                     => 'Reporté'                    , 
	'Medium'                       => 'Normale'                     , 
	'LBL_CHANGE_OWNER'             => 'Changer assignation'         , 
	'LBL_EVENT'                    => 'Activité'                   , 
	'LBL_TASK'                     => 'Pour faire'                      , 
	'LBL_TASKS'					   => 'Pour faire',
	'LBL_CALENDAR_VIEW'            => 'Calendar View'               , 
	'LBL_SHARED_CALENDAR'          => 'Shared Calendar'             , // TODO: Review
	'LBL_DAY0'                     => 'Sunday'                      , // TODO: Review
	'LBL_DAY1'                     => 'Monday'                      , // TODO: Review
	'LBL_DAY2'                     => 'Tuesday'                     , // TODO: Review
	'LBL_DAY3'                     => 'Wednesday'                   , // TODO: Review
	'LBL_DAY4'                     => 'Thursday'                    , // TODO: Review
	'LBL_DAY5'                     => 'Friday'                      , // TODO: Review
	'LBL_DAY6'                     => 'Saturday'                    , // TODO: Review
	'first'                        => 'First'                       , // TODO: Review
	'last'                         => 'Last'                        , // TODO: Review
	'LBL_DAY_OF_THE_MONTH'         => 'day of the month'            , // TODO: Review
	'LBL_ON'                       => 'on'                          , // TODO: Review
	'Daily'                        => 'Day(s)'                      , // TODO: Review
	'Weekly'                       => 'Week(s)'                     , // TODO: Review
	'Monthly'                      => 'Month(s)'                    , // TODO: Review
	'Yearly'                       => 'Year'                        , // TODO: Review
        'LBL_DEFAULT_STATUS_TYPE'      => 'Statut par défaut & Type'    ,
        'LBL_STATUS'                   => 'Statut'                      ,
        'LBL_TYPE'                     => 'Catégorie',
	//Fixing colors for Shared Calendar and My Calendar
	'LBL_EDIT_COLOR' => 'Modifier la couleur',
	'LBL_ADD_CALENDAR_VIEW' => 'Ajouter Calendrier',
	'LBL_SELECT_USER_CALENDAR' => "Sélectionnez Calendrier de l'utilisateur",
	'LBL_SELECT_CALENDAR_COLOR' => 'Sélectionnez Calendrier Couleur',
	'LBL_EDITING_CALENDAR_VIEW' => "Édition Calendrier",
	'LBL_DELETE_CALENDAR' => 'Supprimer Calendrier',
	'LBL_SELECT_ACTIVITY_TYPE' => "Sélectionner le type d'activité",
	'Tasks' => 'Tâches',
);
$jsLanguageStrings = array(
	'LBL_ADD_EVENT_TASK'           => 'Add Event / Pour faire'            , 
	'JS_TASK_IS_SUCCESSFULLY_ADDED_TO_YOUR_CALENDAR' => 'Task is successfully added to your Calendar', // TODO: Review
	'LBL_CANT_SELECT_CONTACT_FROM_LEADS' => 'Cannot select related Contacts for Leads', // TODO: Review
        'JS_FUTURE_EVENT_CANNOT_BE_HELD' => 'Ne peut être tenue Pour l\'avenir',
	
	//Calendar view label translation
	'LBL_MONTH' => 'Month',
	'LBL_TODAY' => 'Today',
	'LBL_DAY' => 'Day',
	'LBL_WEEK' => 'Week',
	
	'LBL_SUNDAY' => 'Sunday',
	'LBL_MONDAY' => 'Monday',
	'LBL_TUESDAY' => 'Tuesday',
	'LBL_WEDNESDAY' => 'Wednesday',
	'LBL_THURSDAY' => 'Thursday',
	'LBL_FRIDAY' => 'Friday',
	'LBL_SATURDAY' => 'Saturday',
	
	'LBL_SUN' => 'Sun',
	'LBL_MON' => 'Mon',
	'LBL_TUE' => 'Tue',
	'LBL_WED' => 'Wed',
	'LBL_THU' => 'Thu',
	'LBL_FRI' => 'Fri',
	'LBL_SAT' => 'Sat',
	
	'LBL_JANUARY' => 'January',
	'LBL_FEBRUARY' => 'February',
	'LBL_MARCH' => 'March',
	'LBL_APRIL' => 'April',
	'LBL_MAY' => 'May',
	'LBL_JUNE' => 'June',
	'LBL_JULY' => 'July',
	'LBL_AUGUST' => 'August',
	'LBL_SEPTEMBER' => 'September',
	'LBL_OCTOBER' => 'October',
	'LBL_NOVEMBER' => 'November',
	'LBL_DECEMBER' => 'December',
	
	'LBL_JAN' => 'Jan',
	'LBL_FEB' => 'Feb',
	'LBL_MAR' => 'Mar',
	'LBL_APR' => 'Apr',
	'LBL_MAY' => 'May',
	'LBL_JUN' => 'Jun',
	'LBL_JUL' => 'Jul',
	'LBL_AUG' => 'Aug',
	'LBL_SEP' => 'Sep',
	'LBL_OCT' => 'Oct',
	'LBL_NOV' => 'Nov',
	'LBL_DEC' => 'Dec',
	
	'LBL_ALL_DAY' => 'All-Day',
	'Mobile Call' => 'Mobile Call',
	//End
	
	//Fixing colors for Shared Calendar and My Calendar
	'JS_CALENDAR_VIEW_COLOR_UPDATED_SUCCESSFULLY' => "Calendrier mis à jour avec succès couleur",
	'JS_CALENDAR_VIEW_DELETE_CONFIRMATION' => 'Etes-vous sûr de vouloir supprimer cette vue du calendrier?',
	'JS_CALENDAR_VIEW_ADDED_SUCCESSFULLY' => "Calendrier ajouté avec succès",
	'JS_CALENDAR_VIEW_DELETED_SUCCESSFULLY' => "Calendrier supprimé avec succès",
	'JS_NO_CALENDAR_VIEWS_TO_ADD' => "Pas Calendrier d'ajouter",
	'JS_EDIT_CALENDAR' => 'Modifier Calendrier',
);
