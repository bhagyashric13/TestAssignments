 <?php
        echo form_open('Dashboard/createAdmission');
        echo form_hidden('fid',$id);
        echo form_label('First Name ');
        echo form_input(array('name' =>'fname'));
        echo "<BR>";
		echo "<BR>";
        echo form_label('Last Name ');
        echo form_input(array('name' =>'lname'));
        echo "<BR>";
		echo "<BR>";
		if($id == 2){
	    	echo form_label('Mother name ');
        	echo form_input(array('name' =>'mothername'));
        	echo "<BR>";
			 echo "<BR>";
		}elseif($id == 3){
			 echo form_label('Phone  ');
        	 echo form_input(array('name' =>'phone'));
             echo "<BR>";
			  echo "<BR>";
		}
        echo form_submit('btnSubmit', 'Submit');        
        echo form_close();
?>
