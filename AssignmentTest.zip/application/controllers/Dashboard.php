<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	function __construct() {
        parent::__construct();
    }
    
	public function index()
	{
		$this->load->view('dashboard');
	}
	public function studentAdmission($id)
	{
		$data['id']=$id;
		$this->load->view('addmissionform',$data);
	}
	public function createAdmission(){
		 $fields = array(
		 		  'formid' => $this->input->post('fid'),	
		          'fname' => $this->input->post('fname'),
		          'lname' => $this->input->post('lname'),
		          'phone' => $this->input->post('phone'),
		          'mothername' => $this->input->post('mothername'),
		);
		$_POST = $fields;
		$ch = curl_init();
        $url = 'http://localhost:81/source65vtiger/modules/Webforms/stud_captureLead.php'; // url to vtiger crm
	    // Set URL and other appropriate options
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($_POST));
		// Send the request
		$result=curl_exec($ch);
		// Close cURL resource, and free up system resources
		curl_close($ch);
		if($result)
		   $this->session->set_flashdata('successes','Thank you !! Admission record save.');
		else {
			$this->session->set_flashdata('successes','Sorry !! Admission record not save.');
		}
		redirect('Dashboard');
	}
	
}
