<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<body>

<?php 
if($this->session->flashdata('successes')) 
   echo $this->session->flashdata('successes'); 
echo "<BR>";
 echo anchor('Dashboard/studentAdmission/1', 'Primary'); 
 echo "<BR>";
 echo anchor('Dashboard/studentAdmission/2', 'Secondary'); 
 echo "<BR>";
 echo anchor('Dashboard/studentAdmission/3', 'HSC');
 echo "<BR>";
  ?>


</body>
</html>