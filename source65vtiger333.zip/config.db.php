<?php
/*+*******************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ********************************************************************************/
  $dbconfig['db_server'] = '_DBC_SERVER_';
  $dbconfig['db_port'] = '_DBC_PORT_';
  $dbconfig['db_sockpath'] = '_DBC_SOCKPATH_';
  $dbconfig['db_username'] = '_DBC_USER_';
  $dbconfig['db_password'] = '_DBC_PASS_';
  $dbconfig['db_name'] = '_DBC_NAME_';
  $dbconfig['db_type'] = '_DBC_TYPE_';
  $dbconfig['db_bundled'] = '_DBC_BUNDLED_';
  $vtconfig['adminPwd'] = '_ADMIN_PASS_';
  $vtconfig['standarduserPwd'] ='_STANDARDUSER_PASS_';
  $vtconfig['adminEmail'] = '_ADMIN_EMAIL_';
  $vtconfig['standarduserEmail'] = '_STANDARDUSER_EMAIL_';
  $vtconfig['demoData'] = '_DEMO_DATA_';
  $vtconfig['currencyName'] = '_CURRENCY_NAME_';
  $vtconfig['quickbuild'] = '_QUICKBUILD_';
?>
